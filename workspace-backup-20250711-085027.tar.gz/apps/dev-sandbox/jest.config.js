/**
 * Jest configuration for Dev app
 */

const nextJest = require('next/jest');
const baseConfig = require("@ioc/testing/test-utils/src/jest.config.base");

const createJestConfig = nextJest({
  // Provide the path to your Next.js app to load next.config.js and .env files in your test environment
  dir: './'
});

// Add any custom config to be passed to Jest
const customJestConfig = {
  ...baseConfig,
  displayName: '@ioc/dev',
  setupFilesAfterEnv: [
  '<rootDir>/../../packages/test-utils/src/jest.setup.js',
  '<rootDir>/jest.setup.js'],

  moduleNameMapper: {
    ...baseConfig.moduleNameMapper,
    // Handle module aliases
    '^@/components/(.*)$': '<rootDir>/components/$1',
    '^@/app/(.*)$': '<rootDir>/app/$1',
    '^@/templates/(.*)$': '<rootDir>/templates/$1',
    '^@ioc/(.*)$': '<rootDir>/../../packages/$1/src'
  },
  testEnvironment: 'jest-environment-jsdom',
  testPathIgnorePatterns: ['<rootDir>/node_modules/', '<rootDir>/.next/'],
  moduleDirectories: ['node_modules', '<rootDir>/'],
  roots: ['<rootDir>'],
  modulePaths: ['<rootDir>'],
  collectCoverageFrom: [
  'app/**/*.{js,jsx,ts,tsx}',
  'components/**/*.{js,jsx,ts,tsx}',
  'lib/**/*.{js,jsx,ts,tsx}',
  'stories/**/*.{js,jsx,ts,tsx}',
  '!**/*.d.ts',
  '!**/node_modules/**',
  '!**/.next/**',
  '!**/*.stories.{js,jsx,ts,tsx}']

};

// createJestConfig is exported this way to ensure that next/jest can load the Next.js config which is async
module.exports = createJestConfig(customJestConfig);