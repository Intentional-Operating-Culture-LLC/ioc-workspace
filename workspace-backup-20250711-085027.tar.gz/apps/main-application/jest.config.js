/**
 * Jest configuration for Production app
 */

const baseConfig = require("@ioc/testing/test-utils/src/jest.config.base");
const path = require('path');

module.exports = {
  ...baseConfig,
  displayName: '@ioc/production',
  rootDir: path.resolve(__dirname),
  moduleNameMapper: {
    ...baseConfig.moduleNameMapper,
    '^@/(.*)$': '<rootDir>/$1',
    '^@ioc/(.*)$': '<rootDir>/../../packages/$1/src'
  },
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: [
  '<rootDir>/../../packages/test-utils/src/jest.setup.js'],

  collectCoverageFrom: [
  'app/**/*.{js,jsx,ts,tsx}',
  'components/**/*.{js,jsx,ts,tsx}',
  'lib/**/*.{js,jsx,ts,tsx}',
  '!**/*.d.ts',
  '!**/node_modules/**',
  '!**/.next/**']

};