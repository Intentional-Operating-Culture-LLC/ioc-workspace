/** @type {import('tailwindcss').Config} */
const { createTailwindConfig } = require('@ioc-core/config/tailwind');

module.exports = createTailwindConfig({
  // Add any app-specific content paths or extensions here
});