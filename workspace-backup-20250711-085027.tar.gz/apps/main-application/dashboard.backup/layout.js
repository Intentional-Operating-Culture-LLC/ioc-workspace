import DashboardLayout from "@ioc/shared/ui";

export default function DashboardRootLayout({ children }) {
  return <DashboardLayout>{children}</DashboardLayout>;
}