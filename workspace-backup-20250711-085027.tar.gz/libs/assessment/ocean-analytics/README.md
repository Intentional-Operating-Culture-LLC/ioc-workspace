# ocean-analytics

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build ocean-analytics` to build the library.

## Running unit tests

Run `nx test ocean-analytics` to execute the unit tests via [Jest](https://jestjs.io).
