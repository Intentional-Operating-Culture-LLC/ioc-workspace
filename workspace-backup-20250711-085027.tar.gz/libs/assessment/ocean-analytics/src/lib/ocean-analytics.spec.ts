import { oceanAnalytics } from './ocean-analytics';

describe('oceanAnalytics', () => {
  it('should work', () => {
    expect(oceanAnalytics()).toEqual('ocean-analytics');
  });
});
