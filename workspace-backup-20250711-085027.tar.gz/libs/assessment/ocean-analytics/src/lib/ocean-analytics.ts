export function oceanAnalytics(): string {
  return 'ocean-analytics';
}
