export function scoring(): string {
  return 'scoring';
}
