import { scoring } from './scoring';

describe('scoring', () => {
  it('should work', () => {
    expect(scoring()).toEqual('scoring');
  });
});
